# VESTORA — Starter technique

Version 0.1 : maquette web responsive destinée à valider l'interface et le parcours produit.

## Contenu
- Accueil VESTORA
- Catalogue de projets d'import-export (exemples)
- Portefeuille de démonstration
- Formulaire visuel de connexion
- Aperçu d'espace administrateur
- Configuration de déploiement Render (`render.yaml`)

## Lancer en local
Prérequis : Node.js 22+ et npm.

```bash
npm install
npm run dev
```
Ouvrir http://localhost:3000.

## Déployer sur Render
1. Créer un dépôt Git privé et y envoyer ces fichiers.
2. Dans Render, choisir **New > Web Service** et connecter le dépôt.
3. Render détectera `render.yaml`, ou utiliser :
   - Build command : `npm install && npm run build`
   - Start command : `npm run start`
4. Déployer et tester l'adresse fournie par Render.

## Limites et sécurité — à lire impérativement
Cette version est une maquette. Elle ne crée pas de vrais comptes, n'enregistre pas les mots de passe, ne conserve pas de solde réel et n'effectue aucun dépôt, investissement ou retrait. Les boutons de démonstration ne déplacent aucun argent.

Ne branchez pas MTN MoMo, Moov Money ou un autre moyen de paiement avant :
- avis juridique sur le modèle de collecte et d'investissement et obtention des autorisations nécessaires ;
- contrats avec les prestataires de paiement ;
- conception d'un grand livre comptable fiable, rapprochement des paiements et contrôle antifraude ;
- authentification sécurisée, vérification d'identité/KYC et contrôle d'accès administrateur ;
- audit de sécurité et tests.

Les investissements comportent un risque de perte. Aucun rendement ne doit être présenté comme garanti.

## Prochaines étapes de développement
1. Valider les écrans et les textes.
2. Concevoir le modèle de données PostgreSQL et le journal comptable en unités monétaires entières.
3. Mettre en place l'authentification et les rôles avec un fournisseur éprouvé.
4. Construire l'administration protégée par MFA et journalisation.
5. Ajouter la gestion des projets, documents justificatifs, frais, risques et résultats.
6. Étudier les intégrations de paiement autorisées, d'abord en environnement sandbox.
7. Ajouter internationalisation et conversion de devises avec taux horodatés et source documentée.
8. Effectuer les audits et préparer les versions mobiles et les dossiers de publication.

## Variables
`.env.example` donne les noms des variables qui pourront être configurées plus tard. Ne jamais publier de clés secrètes dans le code ou dans Git.
