import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VESTORA | Commerce & investissement",
  description: "Espace de démonstration VESTORA.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
