"use client";

import { useState } from "react";

const projects = [
  { name: "Importation de chaussures", category: "Chaussures", description: "Exemple de projet commercial : approvisionnement, transport et revente.", status: "Démo uniquement" },
  { name: "Importation de vêtements", category: "Vêtements", description: "Exemple de projet commercial : achat en gros et distribution.", status: "Démo uniquement" },
];

export default function Home() {
  const [view, setView] = useState("Accueil");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [amount, setAmount] = useState("1000");
  const [message, setMessage] = useState("");

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={() => setView("Accueil")}><span className="brand-mark">V</span> VESTORA</a>
        <span className="demo-pill">ENVIRONNEMENT DE DÉMONSTRATION</span>
      </header>

      <section className="hero">
        <div>
          <p className="eyebrow">COMMERCE • IMPORT-EXPORT</p>
          <h1>Investir dans le commerce, avec plus de visibilité.</h1>
          <p className="hero-copy">Découvrez des opérations commerciales, leurs coûts, leurs risques et leurs résultats documentés.</p>
          <button className="gold-button" onClick={() => setView("Projets")}>Découvrir les projets</button>
        </div>
        <div className="hero-card">
          <p className="muted-light">Portefeuille de démonstration</p>
          <div className="balance">0 FCFA</div>
          <p className="muted-light">Aucun dépôt réel n'est accepté dans cette version.</p>
          <div className="currency-row"><span>FCFA</span><span>EUR</span><span>USD</span></div>
        </div>
      </section>

      <nav className="tabs">
        {["Accueil", "Projets", "Portefeuille", "Connexion", "Administration"].map((item) =>
          <button key={item} className={view === item ? "tab active" : "tab"} onClick={() => { setView(item); setMessage(""); }}>{item}</button>
        )}
      </nav>

      {view === "Accueil" && <section className="content">
        <h2>Bienvenue sur VESTORA</h2>
        <p className="muted">La première version présente l'expérience utilisateur. Les investissements et paiements sont désactivés.</p>
        <div className="notice">Important : les rendements ne sont jamais garantis. Chaque opération doit présenter ses risques, ses frais, sa durée et ses justificatifs.</div>
      </section>}

      {view === "Projets" && <section className="content">
        <h2>Projets commerciaux</h2>
        <p className="muted">Exemples d'interface — aucune collecte de fonds n'est ouverte.</p>
        <div className="project-grid">{projects.map(p => <article className="project" key={p.name}>
          <div className="project-icon">◇</div><span className="tag">{p.status}</span><h3>{p.name}</h3><p>{p.description}</p><button className="outline-button" onClick={() => setMessage("Fiche de projet à compléter : budget, fournisseur, transport, douane, calendrier, risques et autorisations.")}>Voir les détails</button>
        </article>)}</div>
        {message && <p className="notice">{message}</p>}
      </section>}

      {view === "Portefeuille" && <section className="content narrow">
        <h2>Portefeuille</h2><div className="balance-panel"><span className="muted-light">Solde fictif</span><strong>0 FCFA</strong></div>
        <label>Montant de démonstration (FCFA)</label><input value={amount} onChange={e => setAmount(e.target.value)} inputMode="numeric" />
        <button className="gold-button full" onClick={() => setMessage("Mode démo : aucune transaction réelle n'a été effectuée.")}>Simuler une demande</button>
        {message && <p className="notice">{message}</p>}
      </section>}

      {view === "Connexion" && <section className="content narrow">
        <h2>Connexion</h2><p className="muted">Formulaire visuel uniquement. L'authentification sécurisée sera développée avant toute mise en production.</p>
        <label>Numéro de téléphone</label><input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+229..." />
        <label>Mot de passe</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Votre mot de passe" />
        <button className="gold-button full" onClick={() => setMessage("Connexion désactivée dans cette maquette. Aucun identifiant n'est enregistré.")}>Se connecter</button>
        {message && <p className="notice">{message}</p>}
      </section>}

      {view === "Administration" && <section className="content">
        <h2>Espace administrateur</h2><div className="notice">Zone réservée — accès réel non activé. Ne publiez pas cette page comme un panneau d'administration sécurisé.</div>
        <div className="admin-grid"><div><b>Utilisateurs</b><strong>—</strong></div><div><b>Projets</b><strong>2 exemples</strong></div><div><b>Dépôts</b><strong>—</strong></div><div><b>Retraits</b><strong>—</strong></div></div>
      </section>}

      <footer><strong>VESTORA</strong><span>Maquette technique • Version 0.1 • Paiements désactivés</span></footer>
    </main>
  );
}
